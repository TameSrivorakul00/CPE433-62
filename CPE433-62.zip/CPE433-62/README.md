Dot Net Web Server
==================
This is a simple web server implemented in .Net/C#. It has plugin/request routing mechanism, so it should be fun to use. Including plugin is an OX game.

Required software
-----------------
1. .Net Core 7.0 https://www.microsoft.com/net/core
2. Visual Studio Code https://code.visualstudio.com/ (optional)

Please make sure you fork the git repo first, don't try to push to my repo!